# Fábrica de Vídeos IA — Android

Este repositorio genera un APK Android mediante GitHub Actions.

## Compilar el APK
1. Sube todos los archivos de este proyecto al repositorio GitHub (rama `main`).
2. Abre la pestaña **Actions**.
3. Ejecuta **Build Android APK** o espera a que termine el flujo automático.
4. Abre la ejecución completada y descarga el artefacto `fabrica-videos-ia-debug-apk`.
5. Descomprime el artefacto y descarga `app-debug.apk` en tu Android.

## Conectar con el servidor
Al abrir la app, introduce la dirección del servidor de Fábrica de Vídeos IA.
- Si el servidor Node.js se ejecuta en Termux en el mismo teléfono: `http://127.0.0.1:3030`
- Si está desplegado en internet: usa su URL HTTPS.

**Importante:** este proyecto es un contenedor Android WebView. No incluye el backend Node.js ni convierte automáticamente las funciones de IA en servicios móviles. El servidor original debe estar disponible y sus proveedores/API keys configurados. El APK generado es de depuración y no está firmado para distribución pública.
