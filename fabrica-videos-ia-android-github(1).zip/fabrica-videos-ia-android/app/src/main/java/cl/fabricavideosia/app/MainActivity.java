package cl.fabricavideosia.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Color;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private WebView web;
    private LinearLayout root;
    private EditText address;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("fabrica", MODE_PRIVATE);
        showConnect();
    }

    private void showConnect() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 48, 28, 24);
        root.setBackgroundColor(Color.rgb(12, 16, 28));

        TextView title = new TextView(this);
        title.setText("FÁBRICA DE VÍDEOS IA");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 30, 0, 12);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Conecta la app al servidor donde está funcionando tu fábrica. Si la ejecutas en Termux en este mismo celular, usa http://127.0.0.1:3030");
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(15);
        info.setPadding(0, 10, 0, 22);
        root.addView(info);

        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(Color.WHITE);
        address.setHintTextColor(Color.GRAY);
        address.setHint("https://tu-servidor.com");
        address.setText(prefs.getString("url", "http://127.0.0.1:3030"));
        root.addView(address);

        Button go = new Button(this);
        go.setText("CONECTAR");
        root.addView(go);
        go.setOnClickListener(v -> {
            String url = address.getText().toString().trim();
            if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
            prefs.edit().putString("url", url).apply();
            openFactory(url);
        });

        TextView note = new TextView(this);
        note.setText("La aplicación Android es la interfaz móvil. El servidor y las funciones de IA deben estar desplegados y configurados aparte.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(12);
        note.setPadding(0, 24, 0, 0);
        root.addView(note);
        setContentView(root);
    }

    private void openFactory(String url) {
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl(url);
        setContentView(web);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else showConnect();
    }
}
